import type { WebGPURenderer } from 'blaze';
import { BindGroup,Buffer,BufferResource, Geometry,GlProgram, GlShader, GpuProgram, GpuShader,State,UniformGroup,WebGLRenderer } from 'blaze';

import fragShaderCode from './coloured-triangle.frag';
import vertShaderCode from './coloured-triangle.vert';
import wgslShaderCode from './coloured-triangle.wgsl';

// if(!window.GPUBufferUsage)
// {
//     window.GPUBufferUsage = {};
// }

export async function colouredTriangleScene(renderer:WebGPURenderer) {


    const aPosition = new Buffer({
        data: new Float32Array([
            -1, 1, // point 1
            1, 1, // point 2
            -1, -1, // point 3

        ]),
        usage: GPUBufferUsage.VERTEX,
    });

    const aColor = new Buffer({
        data: new Float32Array([
            1, 0, 0, // color 1
            0, 1, 0,// color 2
            0, 0, 1// color 3
        ]),
        usage: GPUBufferUsage.VERTEX,
    });



    const indexBuffer = new Buffer({
        data: new Uint32Array([
            0, 1, 2, // triangle 1
        ]),
       usage: GPUBufferUsage.INDEX,
    });

    
    const geometry = new Geometry({
        attributes: {
            aPosition: {
                buffer: aPosition,
                shaderLocation: 0,
                format: 'float32x2',
                stride: 2 * 4,
                offset: 0,
            },
            aColor:{
                buffer: aColor,
                shaderLocation: 1,
                format: 'float32x3',
                stride: 3 * 4,
                offset: 0,
            }
        },
        indexBuffer
    });

    const gpuProgram = new GpuProgram({
        fragment: {
            source: wgslShaderCode,
            entryPoint: 'mainFrag',
        },
        vertex: {
            source: wgslShaderCode,
            entryPoint: 'mainVert',
        },
    });

    const glProgram = new GlProgram({
        fragment: fragShaderCode,
        vertex: vertShaderCode
    });

    // const gpuShader = new GpuShader({
    //     program:gpuProgram,
    //     groups:[
    //         new BindGroup({
    //             0:new UniformGroup({
    //                 alpha:{value:0, type:'f32'}
    //             })
    //         })
    //     ]
    // });

    const uniformGroup = new UniformGroup({
        alpha:{value:1, type:'f32'},
    });

    uniformGroup.ubo = true;

    renderer.uniformBuffer.updateUniformGroup(uniformGroup);
    
    const bufferResource = new BufferResource({
        buffer:uniformGroup.buffer,
        offset:0,
        size: 4*4
    })

    const gpuShader = new GpuShader({
        program:gpuProgram,
        groups:[
            uniformGroup
        ]
    });

    const glShader = new GlShader({
        program:glProgram,
        uniforms: {
            someVariable:bufferResource,
        },
        // uniformBuffers:[
        //      {index:0, name:'someVariable', uniforms:uniformGroup},
        // ]
    });

    const state = State.for2d();

    const update = ()=>{

        renderer.renderTarget.start(renderer.view.texture, true, renderer.background.colorRgba); 
        
        uniformGroup.uniforms.alpha = Math.random();
        
        renderer.uniformBuffer.updateUniformAndUploadGroup(uniformGroup);
      //  renderer.buffer.updateBuffer(uniformGroup.buffer);
   
        if(renderer instanceof WebGLRenderer)
        {
            renderer.renderTarget.draw(geometry, glShader, state);
        }
        else
        {
            renderer.renderTarget.draw(geometry, gpuShader, state);
        }
        
        renderer.renderTarget.finish();
     requestAnimationFrame(update);
    }

    requestAnimationFrame(update);
    // renderer.renderTarget.finish();
    
}